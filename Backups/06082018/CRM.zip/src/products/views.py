from django.shortcuts import render, redirect
# Agregamos las forma y el modelo para poder darle a la vista la informacion de las rutas de acceso
from .forms import ContactRegisterModelForm, ProductRegisterModelForm, ProviderRegisterModelForm
from .models import ProductRegister, ProviderRegister, ContactRegister, OrderCatalogue

from django.http import HttpResponse
from django.shortcuts import get_object_or_404

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.views import status

import json


def index(request):
    # Validar que el usuario este autenticado
    #if request.user == user.is_authenticated():
        #title = "Bienvenido %s" %(request.user)
    #else:
    title = " :: CRM Index Page ::"
    form = ProductRegisterModelForm(request.POST or None)
    ordenes = OrderCatalogue.objects.all().order_by("id")
    # Methodo is_valid() para generar correctamente el diccionario de datos de la forma
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()

    contexto = {
        "title": title,
        "ordenes":ordenes,
        "indexForm": form,
    }
    return render(request, 'index.html', contexto)

def contact(request):
    title = " :: CRM Contact Page ::"
    form = ContactRegisterModelForm(request.POST or None)
    if form.is_valid():
        nombre = form.cleaned_data.get("nombre")
        mensaje = form.cleaned_data.get("mensaje")
        email = form.cleaned_data.get("email")
        #print "nombre: ",nombre," mensaje: ", mensaje , " email: ",email

    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()

    contexto = {
            "title": title,
            "contactForm": form,
        }

    return render(request, 'contact.html', contexto)

def provider(request):
    title = ":: CRM Provider ::"
    form = ProviderRegisterModelForm(request.POST or None)

    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()

    contexto ={
        "title": title,
        "providerForm": form,
    }
    return render(request, 'provider.html',contexto)

def search(request):
    title = ":: CRM List Products page ::"
    productos = ProductRegister.objects.all().order_by("id")

    contexto= {
        "title" : title,
        "productos": productos,
    }
    return render(request, 'search.html', contexto)

def searchProvider(request):
    title = ":: CRM List Provider page ::"
    proveedores = ProviderRegister.objects.all().order_by("id")

    contexto= {
        "title" : title,
        "proveedores": proveedores,
    }
    return render(request, 'searchProvider.html', contexto)

def searchContacts(request):
    title = ":: CRM List Contacts page ::"
    contactos = ContactRegister.objects.all().order_by("id")

    contexto= {
        "title" : title,
        "contactos": contactos,
    }
    return render(request, 'searchContacts.html', contexto)


def edit(request, id):
    title = ":: CRM Edit page ::"
    producto = ProductRegister.objects.get(id=id)

    if request.method == 'GET':
        form = ProductRegisterModelForm(instance=producto)
    else:
        form = ProductRegisterModelForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('search')
    contexto= {
                "title" : title,
                "producto": producto,
                "form": form,
    }
    return render(request, 'edit.html', contexto)

def delete(request, id):
    title = ":: CRM Delete page ::"
    producto = ProductRegister.objects.get(id=id)

    if request.method == 'POST':
        producto.delete()
        return redirect('search')

    return render(request, 'delete.html', {'producto':producto})


#def to_serialize(obj):
#   return {'nombre': obj.nombre , 'descripcion': obj.descripcion, 'cantidad': obj.cantidad, 'ubicacion': obj.ubicacion,'proveedor': obj.proveedor,  'email':obj.email}


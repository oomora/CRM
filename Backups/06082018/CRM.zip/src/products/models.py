from __future__ import unicode_literals

from django.db import models


class ProductRegister(models.Model):
    nombre      = models.CharField(max_length=35, blank=True,null=True)
    descripcion = models.CharField(max_length=120, blank=True,null=True)
    cantidad    = models.IntegerField()
    cantidad_minima= models.IntegerField(default=0)
    punto_reorden= models.IntegerField(default=0)
    ubicacion   = models.CharField(max_length=10, blank=True,null=True)
    proveedor   = models.CharField(max_length=10, blank=True,null=True)
    fechaIngreso= models.DateField(auto_now_add=True,auto_now=False)
    email       = models.EmailField()

    def __unicode__(self):
        return self.nombre

    def __str__(self):
        return self.nombre

class ProviderRegister(models.Model):
    nombre      = models.CharField(max_length=120,blank=True,null=True)
    rfc         = models.CharField(max_length=20,blank=True,null=True)
    direccion   = models.CharField(max_length=120)
    productos   = models.CharField(max_length=120)
    cantidad    = models.IntegerField()
    punto_reorden = models.IntegerField(default=0)

    def __unicode__(self):
        return self.rfc

    def __str__(self):
        return self.rfc

class ContactRegister(models.Model):
    nombre = models.TextField(max_length=30, blank=True,null=True)
    mensaje = models.TextField(max_length=100, blank=True,null=True)
    email = models.EmailField()

    def __unicode__(self):
        return self.nombre

    def __str__(self):
        return self.nombre

class OrderCatalogue(models.Model):
    nombre = models.CharField(max_length=20, blank=False, null =False)
    label = models.CharField(max_length=20, blank=False, null =False)

    def __unicode__(self):
        return self.nombre

    def __str__(self):
        return self.nombre

# from django.shortcuts import render

# def about(request):
# 	title = " Titulo desde el Warehouse"

# 	contexto = {
# 		"title" : title,
# 	}
# 	return render(request, 'about.html', contexto)

# def search(request):
# 	title =" Titulo desde el Warehouse para Search"
# 	contexto = {
# 		"title" : title,
# 	}
# 	return render(request, 'search.html', contexto)	